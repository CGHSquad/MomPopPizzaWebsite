import javax.swing.*;
import java.awt.*;

public class FrontEnd {
    public void CreateWindow() {
        // Create the main JFrame for the application
        JFrame frame = new JFrame("Mom and Pops Pizzeria");

        // Create the header panel with a specified background color and size
        JPanel header = new JPanel();
        header.setBackground(new Color(58, 34, 32));
        header.setPreferredSize(new Dimension(800, 100));
        header.setLayout(null); // Using absolute positioning

        // Create the lower section panel with GridBagLayout for precise positioning
        JPanel lwrSection = new JPanel(new GridBagLayout());
        lwrSection.setBackground(Color.WHITE);
        lwrSection.setPreferredSize(new Dimension(800, 400));
        lwrSection.setLayout(null); // Using absolute positioning

        // Load images for the logo
        JLabel headLogo = getjLabel();

        // Create a JButton for the shopCart
        ///JButton shopCartButton = getShopCartButton();

        // Create a JButton for the Login
        JButton loginButton = getLoginButton();

        JButton guestButton = getGuestButton();

        JLabel sloganButton = getSlogan();

        // Set up the layout for the main frame
        frame.add(header, BorderLayout.NORTH);
        frame.add(lwrSection, BorderLayout.CENTER);
        header.add(headLogo);
        ///header.add(shopCartButton);// Add the shopCart button to the header panel
        lwrSection.add(loginButton);
        lwrSection.add(guestButton);
        lwrSection.add(sloganButton);

        // Set the size, default close operation, and visibility of the main frame
        frame.setSize(800, 500);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // Function to create and configure the JLabel with the logo
    private static JLabel getjLabel() {
        // Load images for the logo
        ImageIcon logo = new ImageIcon("C:\\Users\\chris\\IdeaProjects\\Sprint2TestChris\\src\\CSEIcons\\logo.png");

        // Create a JLabel for the logo
        JLabel headLogo = new JLabel();
        headLogo.setIcon(logo);

        // Get the dimensions of the image
        int widthLogo = logo.getIconWidth();
        int heightLogo = logo.getIconHeight();

        // Set the bounds of the label to the actual size of the image
        headLogo.setBounds(0, 15, widthLogo, heightLogo);

        return headLogo;
    }

    // Function to create and configure the JButton for the shopCart
    /*private static JButton getShopCartButton() {
        // Load image for the shopCart
        ImageIcon shopCartIcon = new ImageIcon("C:\\Users\\chris\\IdeaProjects\\Sprint2TestChris\\src\\CSEIcons\\ShoppingCart.png");

        // Create a JButton for the shopCart
        JButton shopCartButton = new JButton();
        shopCartButton.setIcon(shopCartIcon);
        shopCartButton.setFocusPainted(false);
        shopCartButton.setContentAreaFilled(false);
        shopCartButton.setBorderPainted(false);

        // Get the dimensions of the image
        int widthCart = shopCartIcon.getIconWidth();
        int heightCart = shopCartIcon.getIconHeight();

        // Set the bounds of the button to the actual size of the image
        shopCartButton.setBounds(700, 25, widthCart, heightCart);

        // Add an ActionListener to handle button clicks
        shopCartButton.addActionListener(e -> {
            // Add your logic for handling shopCart button clicks here
            System.out.println("ShopCart button clicked");
        });

        return shopCartButton;
    }*/

    private static JButton getLoginButton() {
        ImageIcon loginIcon = new ImageIcon("C:\\Users\\chris\\IdeaProjects\\Sprint2TestChris\\src\\CSEIcons\\LoginBrown.png");

        Image image = loginIcon.getImage();
        Image newImage = image.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        loginIcon = new ImageIcon(newImage);

        JButton loginButton = new JButton();
        loginButton.setIcon(loginIcon);
        loginButton.setText("Login");
        loginButton.setFont(new Font(null, Font.PLAIN, 20));

        // Set the background color to brown using RGB (58, 34, 32)
        loginButton.setBackground(new Color(58, 34, 32));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBorder(BorderFactory.createEtchedBorder());

        loginButton.setFocusPainted(false);
        loginButton.setContentAreaFilled(true);
        loginButton.setBorderPainted(false);

        loginButton.setBounds(150, 170, 200, 75);
        loginButton.addActionListener(e -> {
            // Add your logic for handling shopCart button clicks here
            System.out.println("Login button clicked");
        });

        return loginButton;
    }
    private static JButton getGuestButton() {

        JButton guestButton = new JButton();
        guestButton.setText("Continue as a guest");
        guestButton.setFont(new Font(null, Font.PLAIN, 20));
        // Set the background color to brown using RGB (58, 34, 32)
        guestButton.setBackground(new Color(58, 34, 32));
        guestButton.setForeground(Color.WHITE);
        guestButton.setBorder(BorderFactory.createEtchedBorder());

        guestButton.setFocusPainted(false);
        guestButton.setContentAreaFilled(true);
        guestButton.setBorderPainted(false);

        guestButton.setBounds(450, 170, 200, 75);
        guestButton.addActionListener(e -> {
            // Add your logic for handling shopCart button clicks here
            System.out.println("Guest button clicked");
        });

        return guestButton;
    }

    private static JLabel getSlogan() {
        // Load images for the logo
        ImageIcon slogan = new ImageIcon("C:\\Users\\chris\\IdeaProjects\\Sprint2TestChris\\src\\CSEIcons\\Slogan.PNG");

        // Create a JLabel for the logo
        JLabel headLogo = new JLabel();
        headLogo.setIcon(slogan);

        // Get the dimensions of the image
        int widthLogo = slogan.getIconWidth();
        int heightLogo = slogan.getIconHeight();

        // Set the bounds of the label to the actual size of the image
        headLogo.setBounds(225, 45, widthLogo, heightLogo);

        return headLogo;
    }
}